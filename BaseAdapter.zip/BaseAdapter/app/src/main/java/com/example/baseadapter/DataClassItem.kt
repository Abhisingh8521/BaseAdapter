package com.example.baseadapter

data class DataClassItem(
    val name: String? = null,
    val number: String? = null,
    val image: Int? = null,


    )
