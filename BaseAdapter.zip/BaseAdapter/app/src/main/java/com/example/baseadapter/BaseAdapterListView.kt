package com.example.baseadapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class BaseAdapterListView(
    private val context: Context,
    private val listViewItem: ArrayList<DataClassItem>
) : BaseAdapter() {
    override fun getCount(): Int {
        return listViewItem.size
    }

    override fun getItem(p0: Int): Any {
        return p0
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    @SuppressLint("MissingInflatedId", "ViewHolder")
    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {

        val contexts = listViewItem[p0]

        val itemView = LayoutInflater.from(context).inflate(R.layout.baseitemlist, p2, false)

        val studentName = itemView.findViewById<TextView>(R.id.name)
        val studentNumber = itemView.findViewById<TextView>(R.id.number)
        val studentImage = itemView.findViewById<ImageView>(R.id.imageView)

        contexts.image?.let { studentImage.setImageResource(it) }
        studentName.text = contexts.name
        studentNumber.text = contexts.number

        return itemView
    }
}